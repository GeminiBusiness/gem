	
 <? include("includes/header.html") ?>

	<div id="content">
				

<h2>Gemini Business Systems Becomes JADE Partner</h2>
</h3>November, 2003</h3>
<p>
Located in Carmel, Indiana, Gemini Business Systems is a consulting and application development company doing business since 1989. From the start, our company has been dedicated to providing the best possible service to our clients and has been a leader in satisfying clients' needs. We have provided technical support and training in DMSII, COMS, COBOL, LINC, and MCP administration. As our company has grown, there have been many opportunities that have allowed us to provide new services and to branch out into new technologies, further meeting the needs of our customers. Among these new technologies is JADE. The staff at Gemini Business Systems is available to assist you in implementing this exciting new product, and would also welcome the opportunity to provide support for any current legacy needs that your company may have.

</p>
			</div>




 <? include("includes/footer.html") ?>
