	
 <? include("includes/header.html") ?>

	<div id="content">
		
	<h1>	FileVision</h1>
	<p>
Integrates comprehensive document management, information management, document imaging, workflow management and information relationship management into an affordable, scalable and 
easy-to-use software solution.

</p>
Connect to our secure site partner: <a href="http://www.filevision.com" > www.filevision.com</a>

<img src="images/filevision.jpeg" class="right">
				
			</div>




 <? include("includes/footer.html") ?>
