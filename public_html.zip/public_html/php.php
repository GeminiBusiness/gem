	
 <? include("includes/header.html") ?>

	<div id="content">
		
		
		<h1>PHP</h1>
<p>
Gemini Business Systems uses PHP to develop web applications incorporating MYSQL data base technologies.
</p>
				<img src="images/padlock.gif" class="right">
			</div>




 <? include("includes/footer.html") ?>
