	
 <? include("includes/header.html") ?>

	<div id="content">
								<img src="images/pencil.gif" class="right">

				<h1>Solutions</h1>
					<p>
					<span>Company: APS  </span>  
					Albuquerque, NM</br>
					Software: Legacy Student Application </br>
					Solutions: Analysis, Programming Systems Support
					</p>
					<p>
					<span>Company: Seneca Foods   </span>
					 Rochester, NY</br>
					Software: Accounting, Order entry tracking, invoicing system</br>
					Solutions: Analysis, Programming Systems Support
					</p>
					<p>
					<span>Company: Roll Coater    </span>
					 Greenfield, IN</br>
					Software: Customized order entry, inventory control system</br>
					Solutions: Analysis, Programming Systems Support
					</p>
					<p>
					<span>Company: Heritage     </span>
					 Indianapolis, IN</br>
					Software: Team involvement for migration to PeopleSoft  ERP</br>
					Solutions: Design and developed Data Conversion programs
					</p>
					<p>
					Company: Bank of Finland / Unisys of Brazil /
					Unisys of South Africa </br>
					Locations: Helsinki, Finland / Rio de Janeiro, Brazil / 
					South Africa <br>
					Software: Converted COBOL to a 4GL system using ART</br>
					Solutions: Conducted training course; served as Project Leader
					</p>

					<p>
					<span>Company: ESI</span>
					Tallahassee, Florida</br>
					Software:Testing IMPACT-program development tool</br>
					Solutions: Testing, Analysis and Quality Assurance
					</p>
					<p>
					<span>Company: Peters Revington</span>
					Delphi, IN</br>
					Software: Customized, integrated order entry, billing, inventory, and accounting using AS/SET</br>
					Soluitons: Project Leader for design, development, and implementation
					</p>
					<p>
					<span>Company: TIES</span>
					St. Paul, Minn.</br>
					Software: Converted HR payroll application from COBOL to a 4GL system.</br>
					Solutions: Analysis, Design and Development
					</p>
				
			</div>




 <? include("includes/footer.html") ?>
