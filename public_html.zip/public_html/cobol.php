	
 <? include("includes/header.html") ?>

	<div id="content">

				<h1>COBOL
</h1>
<p>

Used Gemini Business Systems' whole systems analysis expertise to enable a steel coating coil production company to replace a cumbersome shipping and inventory system to a single keystroke system connecting bills of lading with invoices, production, and quality services information.
</p>
<p>
Impact of this Project:</br>
	Error rates on bills were reduced to zero!!
	Company benefited with savings for both operations and maintenance.
				            
				            
		</p>
		<span class="right">Roll Coater Inc.
                     </br>                                                                                                Greenfield, IN</span>
                     </br></br>
                     								<img src="images/plant.gif" class="right">

</div>


 <? include("includes/footer.html") ?>
