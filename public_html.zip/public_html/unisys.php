	
 <? include("includes/header.html") ?>

	<div id="content">
				
					<img src="images/guy.gif" class="right">

		
<h1>UNISYS MCP</h1>
<p>
   <strong> DMS II </strong>
   </br>
   
	Analysis of data base statistics</br>
	Tuning for a balanced performance with resource utilization
</p>

<p>
	<strong>COMS </strong></br>
           Administration and operations 
</p>
<p>
   <strong> DEPCON </strong></br>
	Reformatting file to email attachment and posting file to web
</p>





				
			</div>




 <? include("includes/footer.html") ?>
