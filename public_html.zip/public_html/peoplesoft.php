	
 <? include("includes/header.html") ?>

	<div id="content">
				
	<h1>
PeopleSoft
</h1>
<p>
Gemini Business Systems can provide staff to work on a complete PeopleSoft project or provide individuals to work under the direction of the client�s managers. We can provide people to work either on site or remotely.
</p>
<p>
Gemini Business Systems can provide quality support to help your staff with:
<ul>

    <li> Conducting Fit/Gap Analyses</li>
    <li> Systems Analysis and Design</li>
   <li>Development of Functional and Technical Designs</li>
    <li> Legacy Application Data Conversion</li>
    <li>Systems Interface Development</li>
   <li> PeopleTools/PeopleCode Development</li>
    <li>SQR Reports and PeopleSoft Query Development</li>

				</ul>
				</p>
				
			</div>




 <? include("includes/footer.html") ?>
