	
 <? include("includes/header.html") ?>

	<div id="content">
		<h1>LINC/EAE</h1>

<p>
Gemini Business Systems served as an integral partner re-engineering from a Legacy mainframe computer environment to an open computing environment.
</p>
<p>
Impact of this Project:</br>
	A substantial reduction in hardware maintenance costs was realized.
	The new open environment increased development options and user interfaces.
	Nightly off line process was reduced from 6 hours to less than an hour process.
	</p>
	<span class="right">Seneca Foods Corporation
                        <br>
                        Rochester, NY
	</span></br></br></br></br>
					<img src="images/rocks.gif" class="right">

	
				
			</div>




 <? include("includes/footer.html") ?>
