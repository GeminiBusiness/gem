<?
	require_once ("fixforbrowser.php");
	require_once ("session.php"); // this starts the session

?>
