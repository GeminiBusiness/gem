	
 <? include("includes/header.html") ?>

	<div id="content">
				
				<img src="images/guy.gif" class="right">
			<p>					
LINC/EAE

Gemini Business Systems served as an integral partner re-engineering from a Legacy mainframe computer environment to an open computing environment.

Impact of this Project:
	A substantial reduction in hardware maintenance costs was realized.
	The new open environment increased development options and user interfaces.
	Nightly off line process was reduced from 6 hours to less than an hour process.
								Seneca Foods Corporation
                                                                                                 Rochester, NY


COBOL

Used Gemini Business Systems� whole systems analysis expertise to enable a steel coating coil production company to replace a cumbersome shipping and inventory system to a single keystroke system connecting bills of lading with invoices, production, and quality services information.

Impact of this Project:
	Error rates on bills were reduced to zero!!
	Company benefited with savings for both operations and maintenance.
				                                                                     Roll Coater Inc.
                                                                                                                     Greenfield, IN


UNISYS MCP

    DMS II
	Analysis of data base statistics
	Tuning for a balanced performance with resource utilization

    COMS
           Administration and operations 

    DEPCON
	Reformatting file to email attachment and posting file to web


PHP

Gemini Business Systems uses PHP to develop web applications incorporating MYSQL data base technologies.
</p>


			</div>




 <? include("includes/footer.html") ?>
