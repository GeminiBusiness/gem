	
 <? include("includes/header.html") ?>

	<div id="content">
				<br/>
				<img src="images/laptop.gif" class="right" alt="laptop" />
				<p>
				Gemini Business System is a technology-based computer consulting company, providing strategy, implementation, and customized solutions to local business and global organizations.
				</p>
				
					<h2>How your company can benefit from our services:</h2>
					<p>

Systems development, design, and support by our experienced company
Protection of your business information and guard against data loss
Keep your business up and running with a reliable network
Share resources and reduce costs

	</p>


			</div>




 <? include("includes/footer.html") ?>
