	
 <? include("includes/header.html") ?>

	<div id="content">
				
				<h1>About Gemini Business</h1>
				<p>
				Gemini Business Systems Inc. was founded in 1989 and has proudly served corporate, educational, government, and industrial companies with IT solutions nationally and internationally. Based in Carmel, Indiana, our highly experienced professionals put your business first and assist you in developing the perfect IT solutions for your company.
</p>
<h2>We match your company's needs with creative, balanced, on-target computer systems solutions through:
</h2>

<div class="smallbox">
<ul>
<li> Project analysis, strategy, and focused implementation plans </li>
<li> Project management </li>
<li> Data Design </li>
</ul>
</div>
<div class="smallbox">
<ul>
<li> Network & Systems administration </li>

<li> Contract Programming </li>
<li> Technical support and documentation </li>
<li> Web development and design </li>
<li>  Migration expertise </li>
</ul>
</div>

<p>
<strong>Benefits of Computer Management Services:</strong><br>
Protect your business information; guard against data loss
Access business resources and information from virtually anywhere, anytime
Keep your business up and running with a reliable network
Share resources and reduce costs

</p>
<h3>

Our mission is to provide the highest quality and innovative computer technology and systems consulting for all our clientele.
</h3>

			</div>




 <? include("includes/footer.html") ?>
