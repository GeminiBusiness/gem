<?
print "Hello! ";
print $_POST[user];
print "!";

?>