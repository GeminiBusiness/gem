	
 <? include("includes/header.html") ?>

	<div id="content">
		
	<h1>KITTIFF</h1>
	<p>


Kittiff Group offers complete Internet marketing solutions for the business, church or non-profit organization, focusing on website design, e-mail marketing and custom programming. Kittiff Group's products and services are designed to save time, simplify marketing and communications efforts, and promote business growth and prosperity. 

	


</p>
Connect to our secure site partner: <a href="http://www.kittiff.com" > www.kittiff.com</a>
<img src="images/kittiff.jpeg" class="right">

				
			</div>




 <? include("includes/footer.html") ?>
