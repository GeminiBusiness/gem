	
 <? include("includes/header.html") ?>

	<div id="content">
				
				<h1> Jade</h1>
				
				<p>JADE is a revolutionary new product that will make programming easier while still giving you the following:
</p>
<ul><li>
   1. Fully object-oriented - Enables highly complex problems to be mapped, modeled and built.</li><li>
   2. Scalability and performance - Uses a model architecture, which allows systems to grow and scale up incrementally and distribute the workload of a system.
 </li><li>  3. Distributed computing technology - Can be changed on demand as operational and deployment requirements evolve.
  </li><li> 4. Runtime Flexibility - Allows developers to build, run and change their systems with more ease than conventional approaches.
  </li><li> 5. Single technology platform - A complete and fully integrated software platform, enabling all enterprise software development, database management and deployment to be accomplished with this single technology.
  </li><li> 6. Resilience and Availability - It has full rollback or crash recovery and archival recovery that allows technicians to roll-forward through database journals for point-in-time recovery.
</li></ul>
<p>
All of these features are surrounded by trained technical support staff, education and training, plus develpment productivity. As the costs for staff increase, it's imperative to use a tool like JADE to control budgets.
	</p>			
				
				
				
				
			</div>




 <? include("includes/footer.html") ?>
