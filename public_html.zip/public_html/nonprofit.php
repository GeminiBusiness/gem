	
 <? include("includes/header.html") ?>

	<div id="content">
				
				
				<h1>Not for Profit
</h1>
<p>
Gemini has been involved with non-profit organizations since 1989. Our focus with these organizations is to make useful, high-end technology solutions available in a way that benefits each organization on all levels, and leaves it as self-sufficient as possible in managing the solution. Our goals have been to establish a long-term working relationship in serving such organizations and to assist in the accomplishment of their missions by making computing a positive resource.
</p>
<p>
For example, Gemini provides Statistical Analysis services for Creating Positive Relationships, a non-profit organization that promotes abstinence-based sex education for middle schools and high schools. As a non-affiliated entity, we tally test scores and furnish analysis on the effectiveness of the programs CPR offers.
</p>
			</div>




 <? include("includes/footer.html") ?>
